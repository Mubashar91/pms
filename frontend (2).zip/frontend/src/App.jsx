// src/App.jsx
import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Lazy loaded components
const Layout = lazy(() => import('./layout/Layout.jsx'));
const Dashboard = lazy(() => import('./Pages/Dashboard.jsx'));
const MyIssues = lazy(() => import('./Pages/MyIssues.jsx'));
const Inbox = lazy(() => import('./Pages/Inbox.jsx'));
const Projects = lazy(() => import('./Pages/Projects.jsx'));

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="/my-issues" element={<MyIssues />} />
            <Route path="/inbox" element={<Inbox />} />
            <Route path="/projects" element={<Projects />} />
            {/* You can add more nested routes here */}
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
