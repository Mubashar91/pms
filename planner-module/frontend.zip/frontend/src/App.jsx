// src/App.jsx
import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Lazy loaded component
const Layout = lazy(() => import('./layout/Layout'));

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Layout />} />
          {/* Add more routes here */}
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
